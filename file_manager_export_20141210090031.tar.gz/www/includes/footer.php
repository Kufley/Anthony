<?php if (file_exists($_SERVER['DOCUMENT_ROOT'].'/zblock/zbblock.php')) require($_SERVER['DOCUMENT_ROOT'].'/zblock/zbblock.php'); ?>        <!--FOOTER AREA START-->
        <div class="footer_area">
        	<div class="west_islip">Anthony Wilson, RD, MS, CPT |  West Islip, NY - 11795</div>
            <div class="footer_nav">
            	<a href="index.php">Home</a>  |  
                <a href="about-anthony.php">About Anthony</a>  |  
                <a href="services.php">Services</a>  |  
                <a href="executive-weight-loss.php">Executive Weight Loss Coaching Programs</a>  |  
                <a href="weight-loss-articles.php">Weight Loss Articles</a>  |  
             
                <a href="contactus.php">Contact Anthony</a>
            </div>
            <div class="reserved_area">	
         	<div class="reserved_left">All Copyright <?php echo @date('Y');?>. &copy; Reserved Anthony Wilson, RD</div>
            <div class="reserved_right">
            	Web Development <a href="http://Wisitech.com" target="_blank">Wisitech</a>
            </div>
         </div>
            <div class="west_islip">
                DISCLAIMER: This site does not provide medical advice, diagnosis, or treatment. The services and information on this site are for informational purposes only and do not constitute medical advice or a recommendation for your specific condition or situation. Consult with your primary care physician and get approval from them before you make any changes to your lifestyle and before starting any exercise, nutrition, diet, or weight loss program.
            </div>
        </div>
        <!--FOOTER AREA END-->
    </div>
<script>
  (function(i,s,o,g,r,a,m){i['GoogleAnalyticsObject']=r;i[r]=i[r]||function(){
  (i[r].q=i[r].q||[]).push(arguments)},i[r].l=1*new Date();a=s.createElement(o),
  m=s.getElementsByTagName(o)[0];a.async=1;a.src=g;m.parentNode.insertBefore(a,m)
  })(window,document,'script','//www.google-analytics.com/analytics.js','ga');

  ga('create', 'UA-52084741-1', 'weightlosshappens.com');
  ga('send', 'pageview');

</script>
</body>
</html>
