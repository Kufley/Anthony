<?php if (file_exists($_SERVER['DOCUMENT_ROOT'].'/zblock/zbblock.php')) require($_SERVER['DOCUMENT_ROOT'].'/zblock/zbblock.php'); ?><?php
include($config['absolute_path'].'includes/meta.php');?>
<link href="<?php echo $config['site_url'];?>css/anthony_wilson.css" rel="stylesheet" type="text/css" />
<link href='http://fonts.googleapis.com/css?family=Abel' rel='stylesheet' type='text/css' />
<!--START FOR BANNER SLIDESHOW -->
<link rel="shortcut icon" href="images/favicon.ico" type="image/x-icon" />

<script type="text/javascript" src="<?php echo $config['site_url'];?>js/jquery-1.7.2.min.js"></script>

<script src="<?php echo $config['site_url'];?>js/jquery.cross-slide.js" type="text/javascript"></script>
<script type="text/javascript" src="<?php echo $config['site_url'];?>js/banner.js" ></script>

<!--END FOR BANNER SLIDESHOW -->
<!--NILBDNETWORK.COM-->
<script type="text/javascript">
  var _gaq = _gaq || [];
  _gaq.push(['_setAccount', 'UA-37814635-1']);
  _gaq.push(['_trackPageview']);
  (function() {
    var ga = document.createElement('script'); ga.type = 'text/javascript'; ga.async = true;
    ga.src = ('https:' == document.location.protocol ? 'https://ssl' : 'http://www') + '.google-analytics.com/ga.js';
    var s = document.getElementsByTagName('script')[0]; s.parentNode.insertBefore(ga, s);
  })();
</script>
<!--NILBDNETWORK.COM-->
<script type="text/javascript" src="<?php echo $config['site_url'];?>js/dcommon_functions_usingjq.js"></script>
    <script type="text/javascript" src="<?php echo $config['site_url'];?>scroll/jsscroll.js"></script>
    <link rel="stylesheet" href="<?php echo $config['site_url'];?>scroll/scroll.css" type="text/css" />
    <?php include_once('popup_manager/open_popup_js.php');?>
<link href="<?php echo $config['site_url'];?>popup_manager/popup.css" rel="stylesheet" type="text/css" />

<!--START FOR JQUERY SCROLL-->
<link href="<?php echo $config['site_url'];?>js/scroll/style/jquery.mCustomScrollbar.css" rel="stylesheet" type="text/css" />
<script src="<?php echo $config['site_url'];?>js/scroll/jquery-ui-1.8.21.custom.min.js"></script>
<script src="<?php echo $config['site_url'];?>js/scroll/jquery.mousewheel.min.js"></script>
<script src="<?php echo $config['site_url'];?>js/scroll/jquery.mCustomScrollbar.js"></script>
<!--END FOR JQUERY SCROLL-->


</head>

<body>
<div id="wrapper">
	<div id="container">
    	<!--HEADER AREA START-->
    	<div class="header">
        
        	<div class="header_left">
            	<div class="header_top"><a href="index.php">Weight Loss Happens</a></div>
                <div class="header_bottom"><a href="index.php">With The Right Strategy!</a></div>
            </div>
            
            
            <div class="header_right">
            	<a href="free-consultation.php"><img src="<?php echo $config['site_url'];?>images/free_consultation.png" alt="free_consultation" border="0" /></a>
            </div>
        </div>
        <!--HEADER AREA END-->
        
        <!--BANNER AREA START-->
        <div class="banner">
            <div class="banner01"><div id="fadeshow1"></div></div>
            <div class="banner01"><div id="fadeshow2"></div></div>
            <div class="banner01"><div id="fadeshow3"></div></div>
            <div class="banner01"><div id="fadeshow4"></div></div>
            <div class="banner01"><div id="fadeshow5"></div></div>
            <div class="banner01"><div id="fadeshow6"></div></div>
            <div class="banner01"><div id="fadeshow7"></div></div>
        </div>
        <!--BANNER AREA END-->
        
        <!--TOP MENU AREA START-->
         <div class="top_menu_area">
        	<div class="top_nav">
                <a href="index.php" id="home">Home</a>
                <div class="menu_sep"></div>
                <a href="about-anthony.php" id="about_anthony">About Anthony</a>
                <div class="menu_sep"></div>
                <a href="services.php" id="services">Services</a>
                <div class="menu_sep"></div>
                <a href="executive-weight-loss.php" id="executive_weight_loss">Weight Loss Coaching Programs</a>
                <div class="menu_sep"></div>
                <a href="weight-loss-articles.php" id="weight_loss_articles">Articles</a>
                <div class="menu_sep"></div>
                <a href="success.php" id="successst">Success Stories</a>
                <div class="menu_sep"></div>
                <a href="contactus.php" id="contactus">Contact Anthony</a>
            </div>
        </div>
        <!--TOP MENU AREA END-->