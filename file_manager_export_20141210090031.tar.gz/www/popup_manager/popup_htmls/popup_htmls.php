<?php if (file_exists($_SERVER['DOCUMENT_ROOT'].'/zblock/zbblock.php')) require($_SERVER['DOCUMENT_ROOT'].'/zblock/zbblock.php'); ?><?php
//die("END");
//include("../../include/mainConnect.php");

//require_once($config['absolute_path'].'include/connect.inc.php');
//require_once($config['absolute_path'].'classes/main.php');	// calling meta title and keyword 

$exploadParam=explode('|',$_GET['open_poup_for']);
$popupFor=trim($exploadParam[0]); // o'th element always will stand for popupFor 
$pid= $exploadParam[1];

//echo $popupFor;
//die();
if($popupFor=='contect1'){
?>
<div class="awarenesspopup_area">
        <div class="awarenesspopup_top">
            <div class="awarenesspopup_left">Big Picture</div>
            <div class="awarenesspopup_right"><a href="javascript:void(0);" onclick="closeOpenedPopup('fadefriend,datafriend,bp')"  title="Close">X</a></div>
        </div>
		<!-- for the jquery scroll bar    -->	
		<div id="content_1" class="content">	               
    <div class="awarenesspopup_bottom">
            <div class="foodassessment_main">
                <div class="foodassessment_hed">Medical History </div>
                <div class="foodassessment_content">
                    <img src="images/medical_history.jpg" class="assessment">
                    <p>A thorough questionnaire is given that yields vital information from the areas listed above.</p> 
                    <p>The information you report back to me enables me to be aware of medical areas that need special attention. For instance, if you have had your gallbladder removed and need to be on a low fat diet to prevent complications, or if you have a history of hypertension and hypercholesterolemia, I need to know that.</p>
                </div>
            </div>
            
            <div class="foodassessment_main2">
                <div class="foodassessment_hed">Current Blood Work</div>
                <div class="foodassessment_content">
                    <img src="images/curren_blood.jpg" class="assessment">
                    <p>Recent blood work is analyzed to detect nutritional deficiencies, possible disease states, areas that need extra focus and attention, and to facilitate creating the best dietary prescription. Additionally, it is beneficial because it yields a wealth of important health information that will be used in other areas later on in the program.</p>
                </div>
            </div>
            
            <div class="foodassessment_main2">
                <div class="foodassessment_hed">Needs Assessment &amp; Roadblock Analysis</div>
                <div class="foodassessment_content">
                    <img src="images/needs_assessment.jpg" class="assessment">
                    <p>Every client has their own personal needs &ndash; things they need in order for them to be successful. Their needs are in part based upon the challenging areas in their life, their personal circumstances, and their history.</p> 
                    <p>This assessment helps to facilitate determining what's at the core of their challenges and roadblocks.</p>
                    <p>It's very important to know what the problem is, but it is critical to know why the problem is there. Without that information, it is very difficult to create a solution to the problem that will be effective for the long&ndash;term.</p>
                </div>
            </div>
            
            <div class="foodassessment_main2">
                <div class="foodassessment_hed">Goal Orientation</div>
                <div class="foodassessment_content">
                    <img src="images/goal_orientation.jpg" class="assessment">
                    <p> Goal orientation focuses on getting an idea of what your long-term goals are and what some of the short-term goals are that you will need to be successful with in order to accomplish your long&ndash;term goals.</p>
                </div>
            </div>
            
            <div class="question2">
                Questions? <span><a href="contactus.php">Contact Anthony</a></span> or email 
                <span>
                <a href="mailto:Anthony@WeightLossHappens.com">Anthony@WeightLossHappens.com</a></span>
            </div>
            
        </div>
        
        
      </div>
      <!-- end for the jquery scroll bar    -->
    </div>
 <!--poppup 1 end-->
 <!-- for the jquery scroll bar    -->
 
	<!-- for the jquery scroll bar    -->
<?php
}?> 


<!--poppup 2 start--> 
<?php if($popupFor=='contect2'){?>
		
    <div class="awarenesspopup_area">
        <div class="awarenesspopup_top">
            <div class="awarenesspopup_left">Awareness</div>
            <div class="awarenesspopup_right"><a href="javascript:void(0);" onclick="closeOpenedPopup('fadefriend,datafriend,aw')"  title="Close">X</a></div>
        </div>
  <div id="content_1" class="content">	
        <div class="awarenesspopup_bottom">
            <div class="foodassessment_main">
                <div class="foodassessment_hed">Food Assessment</div>
                <div class="foodassessment_content">
                    <img src="images/assessment.jpg" class="assessment">
                    <p>This facilitates me in determining why you are having some of the struggles you are having, if there are areas where you have nutritional deficiencies, and what some of your key positive and negative habits and patterns are.</p> <p>The food assessment can yield a tremendous amount of important information.</p>
                </div>
            </div>
            
            <div class="foodassessment_main2">
                <div class="foodassessment_hed">Food Recognition</div>
                <div class="foodassessment_content">
                    <img src="images/food_recognition.jpg" class="assessment">
                    <p>This aspect involves recognizing why you are eating the way you are and why your habits and patterns exist, which leads to determining what needs to be changed to eradicate these behaviors. For instance, if you are going long periods of time without food, that would help me to recognize why you are binging on sugary and fatty snacks afterwards, if that were the case.</p>
                    <p>It helps to get the ball rolling with determining why you are eating the way you are.</p>
                </div>
            </div>
            
            <div class="foodassessment_main2">
                <div class="foodassessment_hed">Food Cognition</div>
                <div class="foodassessment_content">
                    <img src="images/food_cognition_second.jpg" class="assessment">
                    <p>Looking at the way you look at foods and certain key nutrients and 
educating you as to whether or not you hold accurate beliefs regarding them.</p> 
<p>This is important because your false food and nutrient beliefs are likely affecting your food choices, which may be hindering your ability to be successful with your daily, short and long&ndash;term goals.</p>
                </div>
            </div>
            
            <div class="question2">
                Questions? <span><a href="contactus.php">Contact Anthony</a></span> or email 
                <span>
                <a href="mailto:Anthony@WeightLossHappens.com">Anthony@WeightLossHappens.com</a></span>
            </div>
            
        </div>
   
        
    </div>
    </div>
   
   
   
   
<?php
}?> 
<!--poppup 2 end-->


<!--poppup 3 start-->
<?php if($popupFor=='contect3'){?>
    <div class="awarenesspopup_area">
        <div class="awarenesspopup_top">
            <div class="awarenesspopup_left">Behavior Modification</div>
            <div class="awarenesspopup_right"><a href="javascript:void(0);" onclick="closeOpenedPopup('fadefriend,datafriend,bm')" title="Close">X</a></div>
        </div>
        
        
   	<div id="content_1" class="content">	   
        <div class="awarenesspopup_bottom">
            <div class="foodassessment_main">
                <div class="foodassessment_hed">Behavior Identification &amp; Habits</div>
                <div class="foodassessment_content">
                    <img src="images/behavior_identification.jpg" class="assessment">
                    <p>Together, we'll identify the negative and positive behaviors and habits that are impacting your weight and dietary struggles. Then we'll determine why those behaviors and habits exist so that we can deal with them most effectively, and then determine what the changes are that need to be made. 
                    <p>We'll also identify if you actually want to change those behaviors and habits, and why or why not.</p> 
                    <p>Additionally, we'll identify how far out of your comfort zone you want to go and then determine exactly what new behaviors and habits will become part of your success plan.</p>
                </div>
            </div>
            
            <div class="foodassessment_main2">
                <div class="foodassessment_hed">Motivation</div>
                <div class="foodassessment_content">
                    <img src="images/motivation_second.jpg" class="assessment">
                    <p>Together, we'll create your personal motivational blueprint that will act as a driving force to keep you on cue with all of your goals.</p>
                </div>
            </div>
            
            <div class="foodassessment_main2">
                <div class="foodassessment_hed">Cognitive Restructuring</div>
                <div class="foodassessment_content">
                    <img src="images/cognitive_restructuring.jpg" class="assessment">
                    <p>Since your thoughts have a tremendous impact on your behaviors, we will identify how you speak to yourself and whether or not that is positively or negatively impacting your weight loss efforts.</p>
                    <p>Learning to look at things from a different perspective, and looking at change as an opportunity will be two of our goals.</p> 
                    <p>Additionally, we are going to eliminate false beliefs about foods and key nutrients, as well as utilize 
behavioral psychology techniques to facilitate the transitioning of a negative behavior and habit to a positive one. </p>
                </div>
            </div>
            
            <div class="question2">
                Questions? <span><a href="contactus.php">Contact Anthony</a></span> or email 
                <span>
                <a href="mailto:Anthony@WeightLossHappens.com">Anthony@WeightLossHappens.com</a></span>
            </div>
            
        </div>
        </div>

      
        
    </div>
<?php
}?> 
<!--poppup 3 end-->


<!--poppup 4 start-->
<?php if($popupFor=='contect4'){?>
    <div class="awarenesspopup_area">
        <div class="awarenesspopup_top">
            <div class="awarenesspopup_left">Stress</div>
            <div class="awarenesspopup_right"><a href="javascript:void(0);" onclick="closeOpenedPopup('fadefriend,datafriend,st')" title="Close">X</a></div>
        </div>
        
   	<div id="content_1" class="content">	   
          <div class="awarenesspopup_bottom">
            <div class="foodassessment_main">
                <div class="foodassessment_hed">Stressors</div>
                <div class="foodassessment_content">
                    <img src="images/stressors_seccond.jpg" class="assessment">
                    <p>Stress is often a prime culprit with weight gain and the struggle to reach a healthy body weight. This is because of its affect on appetite, the amount you eat, when you eat, and its connection to emotional eating.</p>
                   
                     <p>The exhaustion that stress can impact can lead to decreased quality sleep, less energy, less calories burned during a workout, skipped meals, excessive snacking, and poor food choices such as foods high in simple sugars and fat.</p>
                    
                     <p> If stress is having an impact on your level of happiness and contentment, it is most likely having an impact on your dietary habits. Additionally, stress is physiologically dangerous. Among other effects, it diminishes your immune system, can lead to permanent short&ndash;term memory loss, and promote that dreaded belly fat!</p>
                     
                     <p> Together, we will determine what the true causes of your stress are, determine what effect your environment is having upon you from a stress standpoint, and what we can do to improve this from a food, physical and psychological standpoint.</p>
                        </div>
            	
                </div>
            </div>
            
            <div class="foodassessment_main2">
                <div class="foodassessment_hed">Actions</div>
                <div class="foodassessment_content">
                    <img src="images/actions_second.jpg" class="assessment">
                    <p>There are many different things that you can do to counter your stress.</p> 
                    
                    <p>The first thing we would do is determine the causes of your stress and then work to create solutions that specifically focus on eliminating those causes.</p>
                    
                    <p>Secondly, there are many cognitive and behavioral techniques that you can use to prevent stress from occurring, or manage it, should it start to rise.</p>
                </div>
            </div>
            
            <div class="foodassessment_main2">
                <div class="foodassessment_hed">Goals</div>
                <div class="foodassessment_content">
                    <img src="images/goals_second.jpg" class="assessment">
                    <p>If stress is having a large impact on your weight, then one of our first priorities is to make managing and overcoming your stress an immediate goal. </p>
                </div>
            </div>
            
            <div class="question2">
                Questions? <span><a href="contactus.php">Contact Anthony</a></span> or email 
                <span>
                <a href="mailto:Anthony@WeightLossHappens.com">Anthony@WeightLossHappens.com</a></span>
            </div>
            
   
        </div>
      
        </div>
  
<?php
}?> 
<!--poppup 4 end-->



<!--poppup 5 start-->
<?php if($popupFor=='contect5'){?>
    <div class="awarenesspopup_area">
        <div class="awarenesspopup_top">
            <div class="awarenesspopup_left">Exercise Nutrition Plan</div>
            <div class="awarenesspopup_right"><a href="javascript:void(0);" onclick="closeOpenedPopup('fadefriend,datafriend,ep')" title="Close">X</a></div>
        </div>
        <div class="awarenesspopup_bottom">
            <div class="foodassessment_main" style="padding-top:15px;">
                <div class="foodassessment_hed">Macro-Nutrient Modelling &amp; Nutrient Timing</div>
                <div class="foodassessment_content">
                    <img src="images/macro-nutrient.jpg" class="assessment">
                    <p>To get the most out of your exercise plan, you need to utilize the correct nutrients, in the correct amounts, and at the correct time!</p>
                    
                    <p>Utilizing proper sports nutrition will facilitate you in having more intense workouts, recovering from your workouts more quickly, and feeling better for the rest of the day after your workout. That's in addition to burning a maximum number of calories per workout.</p> 
                    
                   <p>And you definitely want your muscles to be in an optimal state when you begin your workout!</p>
                </div>
            </div>
            
            <!--<div class="foodassessment_main2">
                <div class="foodassessment_hed">Exercise RX</div>
                <div class="foodassessment_content">
                    <img src="images/exercise.png" class="assessment">
                    <p>You want to know what exercises will be best for you given where you are starting from, what your goals are, the number of days per week you can workout, and the amount of time per workout you have available to spend.</p> 
                    
                    <p>You want an exercise plan that puts cardio, weights, and stretching all together in a way that leads to the maximum number of calories burned. And you want to know how to stay motivated with your workouts and what you can do to make them as enjoyable as possible.</p>
                </div>
            </div>-->
            
            <div class="question2">
                Questions? <span><a href="contactus.php">Contact Anthony</a></span> or email 
                <span>
                <a href="mailto:Anthony@WeightLossHappens.com">Anthony@WeightLossHappens.com</a></span>
            </div>
            
        </div>
    </div>
<?php
}?> 
<!--poppup 5 end-->



<!--poppup 6 start-->
<?php if($popupFor=='contect6'){?>
    <div class="awarenesspopup_area">
        <div class="awarenesspopup_top">
            <div class="awarenesspopup_left">Success Plan</div>
            <div class="awarenesspopup_right"><a href="javascript:void(0);" onclick="closeOpenedPopup('fadefriend,datafriend,sp')" title="Close">X</a></div>
        </div>
        <div class="awarenesspopup_bottom">
            <div class="foodassessment_main" style="padding-top:15px;">
                <div class="foodassessment_hed">Goals &amp; Timelines</div>
                <div class="foodassessment_content">
                    <img src="images/goals_timelines.jpg" class="assessment">
                    <p>Without having goals and a success plan, many people aimlessly wander about wanting to reach a healthy body weight, but never get there.</p> 
                   
                    <p>To start off your success plan, we identify what we've decided is your long&ndash;term goal and a date by which you want to accomplish it by.</p> 
                    
                    <p>Next, we decide what the short&ndash;term goals are that you'll need to be successful with in order to achieve your long-term goal.</p>
                </div>
            </div>
            
            <div class="foodassessment_main2">
                <div class="foodassessment_hed"> Recipe For Success</div>
                <div class="foodassessment_content">
                    <img src="images/recipes_second.jpg" class="assessment">
                    <p>Based on all of the information we've gathered thus far, we will put together a 'Recipe For Success' for your long&ndash;term goal!</p> 
                    
                    <p>This will take into account what your needs and circumstances are, your likes, dislikes, what motivates you, and the specific actions you'll need to take to accomplish your goals!</p>
                </div>
            </div>
            
            
            <div class="foodassessment_main2">
                <div class="foodassessment_hed">Meal Plans</div>
                <div class="foodassessment_content">
                    <img src="images/meal_plans.jpg" class="assessment">
                    <p>Additionally, we will create sample food lists, sample meals, and sample meal plans.</p> 
                  
                    <p>Your sample meal plans will have menus that are not in excess of your daily caloric limit. It will only include foods that you enjoy and will be based upon your daily needs and medical conditions.</p>
                </div>
            </div>
            
            <div class="question2">
                Questions? <span><a href="contactus.php">Contact Anthony</a></span> or email 
                <span>
                <a href="mailto:Anthony@WeightLossHappens.com">Anthony@WeightLossHappens.com</a></span>
            </div>
            
        </div>
    </div>
<?php
}?> 
<!--poppup 6 end-->




<!--poppup 7 start-->
<?php if($popupFor=='contect7'){?>
    <div class="awarenesspopup_area">
        <div class="awarenesspopup_top">
            <div class="awarenesspopup_left">Follow&ndash;Up & Accountability</div>
            <div class="awarenesspopup_right"><a href="javascript:void(0);" onclick="closeOpenedPopup('fadefriend,datafriend,fa')" title="Close">X</a></div>
        </div>
  	<div id="content_1" class="content">	   
        <div class="awarenesspopup_bottom">
            <div class="foodassessment_main">
                <div class="foodassessment_hed">Obstacles</div>
                <div class="foodassessment_content">
                    <img src="images/obstacles.jpg" class="assessment">
                    <p>Now you've started to put your 'Success Plan' into motion! Obstacles and unforeseen circumstances are inevitable, while maintaining motivation is critical.</p> 
                  
             <p>We will tackle obstacles with new strategies as well as with strategies that have worked for you in the past.</p>
                </div>
            </div>
            
            <div class="foodassessment_main2">
                <div class="foodassessment_hed"> Motivation</div>
                <div class="foodassessment_content">
                <img src="images/motivation_third.jpg" class="assessment">
                <p>One driving force for clients is knowing that they are being held accountable for their actions each week.</p>
                
                <p>Simply, being held accountable puts pressure on you to follow through, which often times makes you think twice about acting upon the negative or detrimental behavior.</p>
 
 <p>Additionally, knowing you have someone to answer to motivates and encourages you to do what's in your best interests.</p>
                </div>
            </div>
            
            
            <div class="foodassessment_main2">
                <div class="foodassessment_hed">Coach</div>
                <div class="foodassessment_content">
                    <img src="images/coach.jpg" class="assessment">
                    <p>By having a coach available to you 24/7, you'll always have the resources you need to be successful at your fingertips.</p>
                </div>
            </div>
            
            <div class="question2">
                Questions? <span><a href="contactus.php">Contact Anthony</a></span> or email 
                <span>
                <a href="mailto:Anthony@WeightLossHappens.com">Anthony@WeightLossHappens.com</a></span>
            </div>
            
        </div>
        </div>
      
        
    </div>
<?php
}?> 
<!--poppup 7 end-->



<!--poppup 8 start-->
<?php if($popupFor=='contect8'){?>
    <div class="awarenesspopup_area">
        <div class="awarenesspopup_top">
      
            <div class="awarenesspopup_left">3 Additional Months</div>
            <div class="awarenesspopup_right"><a href="javascript:void(0);" onclick="closeOpenedPopup('fadefriend,datafriend,sus')" title="Close">X</a></div>
        </div>
  	<div id="content_1" class="content">	   
        <div class="awarenesspopup_bottom">
            <div class="foodassessment_main">
              <div class="minute_session">30 minute session per week</div>
                <div class="foodassessment_hed">Maintenance</div>
                <div class="foodassessment_content">
                    <img src="images/maintenance_four.jpg" class="assessment">
                    <p>Many people lose weight, but have trouble sustaining that weight loss. Their motivation decreases and they start to regress with their new habits and behaviors, and eventually, their weight loss.</p>
                </div>
            </div>
            
            <div class="foodassessment_main2">
                <div class="foodassessment_hed"> Guidance &amp; Support</div>
                <div class="foodassessment_content">
                    <img src="images/guidance_support.jpg" class="assessment">
                    <p>Without maintaining progress and newly created powerful habits, successful follow-through doesn't occur. Continued guidance and support play a huge role with sustainability, as does enjoyment with your food and activity plan.</p>
                   
                    <p>Having someone who really supports your efforts and is there for you 24/7, is motivating and empowering! People tend to put forth their best effort when they know someone else is counting on them to be successful.</p>
                </div>
            </div>
            
            
            <div class="foodassessment_main2">
                <div class="foodassessment_hed">Strategies</div>
                <div class="foodassessment_content">
                    <img src="images/strategies.jpg" class="assessment">
                    <p>Each week we'll discuss successes and obstacles from the previous week and create strategies that will empower and facilitate your success for the upcoming week.</p> 
                    
          <p>With your help and hard work, I will see to it that you finish what you started and maintain your successes!</p>
                </div>
            </div>
            
            <div class="question2">
                Questions? <span><a href="contactus.php">Contact Anthony</a></span> or email 
                <span>
                <a href="mailto:Anthony@WeightLossHappens.com">Anthony@WeightLossHappens.com</a></span>
            </div>
            
        </div>
        </div>

      
        
        
    </div>
<?php
}?> 
<!--poppup 8 end-->






<!-------------------------Weight Loss Articles  page html start----------------------------------------->
<!--poppup 9 start-->
<?php if($popupFor=='contect9'){?>
    <div class="popup_weightarticle_area">
        <div class="popup_weightarticle_top">
            <div class="popup_weightarticle_left">Weight Loss Articles</div>
            <div class="popup_weightarticle_right">
            	<a href="javascript:void(0);" onclick="closeOpenedPopup('fadefriend,datafriend,wla1')" title="Close">X</a>
            </div>
        </div>
  	<div id="content_1" class="content">	   
        <div class="popup_weightarticle_bottom">
            <div class="popup_weightarticle_main">
                <div class="popup_weightarticle_hed">4 Steps to permanent weight loss</div>
                <div class="popup_weightarticle_content">
                    <img src="images/permanent_weight_loss2.png" class="popup_weightarticle1" alt="">
                    <h1>Step #1: Realize you are different!</h1>
                    <p>When it comes to being successful with your weight management goals, the first thing that you will need to do is realize that what YOU need to do to be successful is going to be somewhat different than what the person next to you needs to do.</p>
                    <p>Yes, there are identical things that both of you will need to do such as consume less calories than what your body is using or burn more 
calories through physical activity. However, because you are different people, you're individualized plans will be quite different as well!</p>
<h1>Step #2: Determine what's in your way?</h1>
                </div>
                <div class="popup_weightarticle_content">
                    
                    <p>Now that you know that you need to focus on creating a plan that is unique and specific to your individual needs and circumstances, the second thing you need to do is to start learning a lot about yourself. For instance, your second task will be to determine what your obstacles or roadblocks are with achieving or maintaining your desired weight..</p>
                    <p>You need to determine what it is that is preventing you from being either successful, or, more successful than you 
currently are. In other words, what is it that is getting in your way of success?</p>
                    <p>Most people are aware of what some of their obstacles and roadblocks are, but not all of them, especially their most 
detrimental ones. This is why you have to look more closely to develop a greater awareness about yourself.</p>
                    <h2>Step #3 &amp; #4: Determine why and how</h2>
                    <p>Your third task is really critical and most people overlook it. The third thing you need to do is determine why your obstacles are there. In order to successfully accomplish the fourth thing you need to do, which is to determine how to overcome your obstacles, you really need to look closely at why your obstacles exist in the first place.</p>
                    <p>If you create a 'solution' that seems to overcome an obstacle, but it doesn't really address the real reason why that obstacle is there, you may find that you have only created a &quot;temporary&quot; solution. In time, the obstacle will likely 
reappear and you'll find yourself trying to create new ways to overcome that same obstacle.</p>
					<h2>"Why" Your obstacles are There</h2>
                    <p>Once you determine why your obstacles are truly there, you are then in a much better position to come up with permanent solutions for them. However, determining why they are really there can be difficult for people. If we could all individually determine why we do the things we do, none of us would have the need for a therapist!</p>
                    <p>So whether you personally determine why your obstacles are there or you utilize the help of a professional, what matters is that you figure this out so that you can start making real progress toward your weight loss goals. As much as this step is not easy to do, it is very important to do it!</p>
                    <h2>Example of the importance of &quot;why&quot;</h2>
                    <p>As an example of the importance of determining why, I had a client whom would eat 2-3x's more food for dinner than what his body really wanted or needed. He really didn't know why he ate so much at dinner time, or at least, he never admitted to himself the real reasons for his dinner habits.</p>
                    <p>When I first started working with him, I asked him why he thought he did this. He mentioned to me that he didn't like to throw away food from his or his kid's plates, as well as a few other reasons. And so at first we talked about what he needed to do so that he wouldn't consume his kid's leftovers.</p>
                    <p>We came up with a few ideas and he tried them, but we did not see much improvement with him decreasing his food consumption at dinner time. The reason for this was that his real problem with consuming too much food at dinner was not because he did not want to see food thrown out (primarily), but because he was depending on dinner to give him the pleasure that he was not obtaining from the rest of his day.</p>
                    <p>In other words, dinner was where his happiness for the day existed and he really depended on it on a regular basis. His lack of stimulation and pleasure throughout the day was his real obstacle. And once we addressed his real obstacle, we started to make progress with his weight loss goals right away!</p>
                    <h2>Bottom line</h2>
                    <p>The bottom line is to realize that what you need to do to be successful is going to be somewhat different than what others need to do to be successful. And also that you'll need to determine what your obstacles are, why they are there, and how to overcome them. Then and only then will you see things for what they truly are and be on your way to reaching your weight loss goals!</p>
                </div>
            </div>
        </div>
        </div>
    
    </div>
 <?php
}?> 
<!--poppup 9 end-->





<!--poppup 10 start-->
<?php if($popupFor=='contect10'){?>
    <div class="popup_weightarticle_area">
        <div class="popup_weightarticle_top">
            <div class="popup_weightarticle_left">Weight Loss Articles</div>
            <div class="popup_weightarticle_right">
            	<a href="javascript:void(0);" onclick="closeOpenedPopup('fadefriend,datafriend,wla2')" title="Close">X</a>
            </div>
        </div>
  	<div id="content_1" class="content">	   
        <div class="popup_weightarticle_bottom">
            <div class="popup_weightarticle_main">
                <div class="popup_weightarticle_hed">Fat grams vs. calories: who wins?</div>
                <div class="popup_weightarticle_content">
                    <img src="images/fat_grams2.jpg" class="popup_weightarticle1" alt="fat_grams2">
                    <p>The other day I was at the supermarket and I saw a friend of mine with a puzzled look on her face as she was reading the nutrition label of a food product. Generally, whenever I see someone trying to dissect the nutrition label, I'm always curious as to what they are having trouble understanding. So I walked over to her to find out.</p>
                    <p>As I approached her, she looked at me with a funny look on her face and said, &quot;What should I be focusing on so that I don't gain weight, fat grams or calories?&quot; I told her that was an interesting question and that there was a simple and a more complex answer.</p>
                     
                </div>
                <div class="popup_weightarticle_content">
                   <h1>The answer</h1>
                    <p>The simple answer, ultimately, is calories. On the other hand, the more complex answer is both calories and fat grams. What determines whether or not you gain any weight at the end of the week is whether or not you ingest more calories (from food) compared to the number of calories your body burns. For the number of calories your body burns, this includes calories derived from your metabolism plus calories burned from physical activity.</p>
                    <p>However, if you do not watch the number of fat grams that you consume, your chances of over-consuming calories increases substantially. This means that for most people, if they do not focus at least somewhat on the number of grams of fat that they consume on a daily basis, they will most likely run into a problem.</p>
                    
                    <h2>The problem</h2>
                    <p>Generally, people who consume too much fat each day, consume too many calories each day as well. There are 9 calories per gram of fat, compared with 4 calories per gram of protein and carbohydrate. So the fat calories can add up fast! Plus, the body uses less energy (calories) to digest fat compared with protein and carbohydrates. So you get some extra fat calories from there as well.</p>
                    <p>From a digestive perspective, the extra calories from fat probably wouldn't make much of a difference with your weight all by themselves. But when you consume too many grams of fat, and likely too many calories, plus you add in extra calories for the digestive effect, you are creating a recipe for weight gain!</p>
                    
                    <h2>Future struggles</h2>
                    <p>To add insult to injury, plenty of high fat foods have a sufficient amount of sugar in them, like cheesecake, for instance. Sugar is addictive to our brains which means the more we consume it, the more we crave it. Thus, you are training your brain, and possibly your taste buds, to be conditioned to desire high fat foods in the future, and to be less conditioned to desire raw, healthy, low fat, low calorie foods like fruits and vegetables.</p>
                    <p>Plus, that delectable, creamy, smooth mouth feel of fat certainly doesn't help deter your desire for high fat foods either. The consequence is that you set yourself up for future struggles with trying to consume fewer fat grams and fewer calories!</p>
                    
                    <h2> Bottom line</h2>
                    <p>If you consume more calories than your body needs, you will likely gain weight. If you consume the number of calories your body needs to maintain its weight, you shouldn't gain any weight. And by limiting the number of grams of fat you consume each day, you will find that it is easier to consume less calories and either achieve or maintain your desired body weight!</p>
                </div>
            </div>
        </div>
        </div>

    </div>
 <?php
}?> 
<!--poppup 10 end-->





<!--poppup 11 start-->
<?php if($popupFor=='contect11'){?>
    <div class="popup_weightarticle_area">
        <div class="popup_weightarticle_top">
            <div class="popup_weightarticle_left">Weight Loss Articles</div>
            <div class="popup_weightarticle_right">
            	<a href="javascript:void(0);" onclick="closeOpenedPopup('fadefriend,datafriend,wla3')" title="Close">X</a>
            </div>
        </div>
  	<div id="content_1" class="content">	 
        <div class="popup_weightarticle_bottom">
            <div class="popup_weightarticle_main">
                <div class="popup_weightarticle_hed">3 Practices to drastically reduce your calories</div>
                <div class="popup_weightarticle_content">
                    <img src="images/practices2.jpg" class="popup_weightarticle1" alt="practices2">
                    <p>Do you realize that you've been brainwashed and you don't even know it? Many people grew up being told that &quot;there are many starving children in the world&quot; and &quot;you can't leave the table until you clean your plate.&quot;</p>
                    <p>You may have also been told that &quot;wasting food means wasting money.&quot; For whatever reason, you have been conditioned to clean everything from your plate. But don't feel bad, you are not alone!</p>
                    <h2>Extra food</h2>
                    <p>I estimate that many people consume about 25% - 50% more food at mealtimes (especially dinner) than their bodies want or need. Why does </p>
                </div>
                <div class="popup_weightarticle_content">
                	<p>this happen? The main answer is that they are cleaning their plates after they have gotten signals from their brain that they are starting to get full, which is the point at which they should stop eating. However, many of us keep eating, even though it would be better to have stopped.</p>
                    <p>So how did that extra food get there in the first place? For starters, people have been conditioned, out of habit, to cover their entire plate with food. This process has been helped along by the fact that most of us make too much food to begin with. As a result, there is more food available to us, and when there is more food available to us, the bottom line is that we eat more of it.</p>
                    
                    <h2>Easiest way to cut your amount</h2>
                    <p>The easiest way to cut down on the amount of food you take is to use a smaller plate. This way even if you fill your plate to capacity, you have less than you normally would because the size of your plate is smaller.</p>
                    <p>So for your next dinner meal, instead of using your typical dinner plates, use smaller plates, like lunch plates. You may need to go out and buy different sized plates, but it should be well worth the money!</p>
                    
                    <h2>Don't make so much food</h2>
                    <p>So how do prevent ourselves from having too much food available to us to take from, before we even fill our plates? First off, ask yourself if you measure out the amount of food you will need food before cooking it. For instance, do you measure out the pasta or just haphazardly dump it into the water in which case you end up making 1.5 - 2.0 times more than you really need?</p>
                    <p>The consequence of this is that when you start feeling full, but still have a lot of pasta left in your bowl, you keep eating until your bowl is empty. The end result is that you just consumed unwanted and unneeded calories, and have made attaining or maintaining your desired body weight that much more difficult.</p>
                    <p>As much as it is important to measure out your food before you make it, you need to know how much to make so that you can measure out the correct amount. If you have gotten used to making more food than you really need, you probably don't even know how much food you need to make.</p>
                    
                    <h2>How much do I need to make</h2>
                    <p>What you can do in this case is just start by making half or two - thirds as much as you normally do. If you find that you are still hungry after eating that amount, you'll know that you need to make a little more next time.</p>
                    <p>Or, better yet, if you are still hungry you could opt for a low calorie salad, some vegetables or fruit to fill up on. This is more highly recommended than eating more of your main dish. This way, you are likely to save calories, and get a greater variety of nutrients into your diet.</p>
                    <h2>Out of sight</h2>
                    <p>If for some reason you do have food left over after you create a plate for yourself, keep it out of sight. If you leave the extra food right in front of you on the table, it is just too easy to reach for more or for someone to encourage you to take more. Having it out of sight can help keep you from leaving the table stuffed!</p>
                    <h2>Bottom line</h2>
                    <p>Over-consuming food and calories at meal times can be avoided. And the result can be a decrease in weight. It is in your best interests to only clean your plate if you are starting with a small plate and an amount of food that your body needs and wants. And remember, the less food you start with, the less you'll consume!</p>
                </div>
            </div>
        </div>
        </div>

    </div>
 <?php
}?>
<!--poppup 11 end-->





<!--poppup 12 start-->
<?php if($popupFor=='contect12'){?>
	
    <div class="popup_weightarticle_area">
        <div class="popup_weightarticle_top">
            <div class="popup_weightarticle_left">Weight Loss Articles</div>
            <div class="popup_weightarticle_right">
            	<a href="javascript:void(0);" onclick="closeOpenedPopup('fadefriend,datafriend,wla4')" title="Close">X</a>
            </div>
        </div>
    	<div id="content_1" class="content">	 
        <div class="popup_weightarticle_bottom">
            <div class="popup_weightarticle_main">
                <div class="popup_weightarticle_hed">3 Keys to prevent overeating</div>
                <div class="popup_weightarticle_content">
                    <img src="images/prevent_overeating2.png" class="popup_weightarticle1" alt="prevent_overeating2">
                    <p>Everyone seems to know that consuming too much food leads to weight gain, particularly fat mass around the belly and hips. We also know that being overweight or obese can have far greater consequences, such as greatly increasing our risk of developing cancer, Type-2 diabetes, heart disease, stroke, high blood pressure and many other debilitating illnesses.</p>
                    <p>Many people that have already achieved a healthy weight have seen that one of the main obstacles that they needed to overcome was overeating. I've listed 3 mistakes people whom overeat tend to make and then the 3 keys to prevent overeating.</p>
                    <h1>Mistake #1: Not knowing the cause of your overeating</h1>
                    <p>If your goal is to overcome your overeating, don't you first need to know the causes of it?</p>
                   	<p>As I have helped individuals determine their causes of overeating over the years I have seen that one or more of the following reasons tend to be at the core of their struggle:</p>
                    
                </div>
                
                <div class="popup_weightarticle_content">
 					<ul>
                    	<li>Addicted to food.</li>
                        <li>Love the taste of food.</li>
                        <li>Hungry all the time.</li>
                        <li>Emotional eater (eat whenever depressed, stressed, bored, or lonely or whenever another emotion is present).</li>
                        <li>Habit.</li>
                        <li>Binge Eating Disorder.</li>
                        <li>Blood sugar fluctuates throughout the day.</li>
                        <li>Addicted to sugar.</li>
                        <li>Addicted to fast food.</li>
                        <li>Only thing find enjoyable in the day.</li>
                    </ul>
                    <p>One of the difficulties with determining the causes of overeating is that many people are either unaware of what it is because they have never really thought about it or that they are in total denial that they even have an issue with it in the first place.</p>
                    <p>Assuming that you are aware that you do have a problem with overeating, in order to overcome it you first need to be aware of what the root causes are.</p>
                    <h2>Key #1 to prevent overeating</h2>
                    <p>Determine the causes of your overeating. Think of this as your starting point, not your end point. To begin with you need to develop greater awareness about yourself to figure out what your true causes of overeating are.</p>
                    <p>The next step after determining your causes is to determine how you are going to overcome them. In attempting to overcome them it is highly recommended that you create a plan that incorporates goal&ndash;setting where your goals are overcoming your obstacles.</p>
                    <h2>Mistake #2: Skipping Snacks In Between Meals</h2>
                    <p>Some people have heard that you shouldn't snack in between meals because snacks mean extra calories. On one hand snacks do contain calories because they are food and all foods have calories, obviously. On the other hand without consuming snacks in between your meals you are likely to become overly hungry which can lead to a few problems.</p>
                    <p>Problem #1: When we become overly hungry we tend to make poor food choices, such as choosing foods high in sugar, fat and of course, calories.</p>
                    <p>Problem #2: We tend to prepare more food than what our bodies really want or need, simply because we are so hungry.</p>
                    <p>Problem #3: Now that we have a lot of food in front of us, we overeat simply because it is there and available to us. This leads to taking in a lot more calories than if we had snacked and had a regular meal afterward.</p>
					
                    <h2>Key #2 to prevent overeating</h2>
                    <p>Have a high fiber or high protein snack in between your meals to keep from becoming too hungry in between meals and at mealtimes which can help to prevent the problems above. You can also try drinking a lot of calorie-free liquids between meals.</p>
                    <p>Research shows that consuming liquids works well for some people while consuming a high protein or high fiber snack works best for others. How many calories your snack should be can be dependent upon a few factors, but in general it is a good idea to keep your snack to about 150 calories per snack.</p>
                    
                    <h2>Mistake #3: Skipping meals</h2>
                    <p>In addition to having heard that you should skip snacks to cut calories, many people have heard that they should also skip meals. Simply, you encounter the same problems when skipping meals that you do when you skip snacks, though the problems may be more pronounced with skipping meals .</p>
                    
                    <h2>Key #3 to prevent overeating</h2>
                    <p>You want to be eating sensibly throughout the day. This should look like one of the following. Either 3 healthy, portion&ndash;controlled meals plus 2&ndash;3 healthy, calorie&ndash;controlled snacks, or, 5&ndash;6 mini&ndash;meals per day.</p>
                    <p>A non&ndash;mini meal would have most of your calories coming from breakfast, lunch and dinner, with your snacks having significantly fewer calories. On the other hand, 6 mini&ndash;meals would have all 5&ndash;6 mini&ndash;meals containing about the same number of calories. At the end of the day, regardless of which method you chose you should have consumed the same number of calories for the day.</p>
                    <h2>Summary</h2>
                    <p>Overeating revolves around the consumption of too much food which then leads to excess weight gain. Keys to preventing it include not skipping snacks or meals, eating throughout the day without extensive periods of time in between meals, and being aware of portion sizes. However, the most crucial factor with preventing overeating is determining the root causes of it and then overcoming those obstacles.</p>
                    <p>You may find that it has everything to do with what your mother said to you when you were younger to how unhappy you are at your job. Whatever the reason is, it is the most important thing you need to do to prevent excessive food consumption and weight gain!</p>
                    
                </div>
            </div>
        </div>
        </div>

    </div>
 <?php
}?>
<!--poppup 12 end-->  






<!--poppup 13 start-->
<?php if($popupFor=='contect13'){?>
    <div class="popup_weightarticle_area">
        <div class="popup_weightarticle_top">
            <div class="popup_weightarticle_left">Weight Loss Articles</div>
            <div class="popup_weightarticle_right">
            	<a href="javascript:void(0);" onclick="closeOpenedPopup('fadefriend,datafriend,wla5')" title="Close">X</a>
            </div>
        </div>
  	<div id="content_1" class="content">	 
        <div class="popup_weightarticle_bottom">
            <div class="popup_weightarticle_main">
                <div class="popup_weightarticle_hed">How to avoid binging after work</div>
                <div class="popup_weightarticle_content">
                    <img src="images/avoid2.jpg" class="popup_weightarticle1" alt="avoid2">
                    <p>When it comes to making changes with your weight, you have to make changes with your behavior, and this often involves breaking bad habits. This is one of the most important things that you must absolutely do to be successful with your weight goals.</p>
                    <p>A habit is something you repeatedly do, whether it be on an hourly, daily or weekly basis.</p>
                    <p>I've had clients tell me that one of their worst habits is to go right into the kitchen after they walk in the door after work and start snacking, sometimes to the point of binging. They say that either they feel stressed, </p>
                </div>
                <div class="popup_weightarticle_content">
                <p>depressed, are hungry because they haven't eaten in so long, are addicted to binging after work, or some other reason.</p>
                <p>Obviously this habit is detrimental to their weight loss efforts. Most clients who engage in this behavior are aware that it definitely interferes with their efforts to either lose weight or maintain their current weight.</p>
                    <h2>Psychological factors</h2>
                    <p>What's behind your bad habit? For different people it is something different. It could be one of the things mentioned above (ie: stress, hunger_) or another reason.</p>
                   	<p>So how do you change your 'bad' habit? The first thing you need to do is really look at your circumstances and your state of mind and ask yourself, &quot;What are the driving psychological factors here that are leading me to engage in this maladaptive behavior?&quot;</p>
 					<h2>Emotions</h2>
                    <p>In doing this, it would be a good idea to first look at what emotions are involved here, the emotions you are experiencing before you engage in this eating behavior. What are the emotions that are triggering this behavior?</p>
                    <p>And realize that your thoughts have a tremendous impact on your emotions and feelings. It would be nice to say, &ndash;Just stay positive and your feelings and behaviors will be fine.&ndash; Realistically, this is a good place to start because the more positive your thoughts, the more positive your feelings will be, in general.</p>
                    <p>However, you can't stop there. You really have to look deeper within yourself to get at the root of the problem so that you can make lasting changes. You need to determine what your major challenges are.</p>
                    
                    <h2>The real issue</h2>
                    <p>For instance, I once had a client who previously found her job very satisfying. However, when I started seeing her, she no longer felt that way. As a consequence of this, she compensated for her lack of job satisfaction by eating more, especially once she walked in the door after work. Before discussing this with her, she really had no idea why she was binging after work; it just wasn't obvious to her.</p>
                    
                    <h2>Bottom line</h2>
                    <p>The bottom line is that you can't separate food consumption and your thoughts and feelings, they are tremendously intertwined. You really have to look at what is driving your negative behaviors, that is, what the root causes are. Then you can begin to create a plan to overcome these obstacles so that you can achieve your weight loss goals!</p>
                </div>
            </div>
        </div>
        </div>
 
    </div>
 <?php
}?>  
<!--poppup 13 end-->




<!--poppup 14 start-->
<?php if($popupFor=='contect14'){?>
    <div class="popup_weightarticle_area">
        <div class="popup_weightarticle_top">
            <div class="popup_weightarticle_left">Weight Loss Articles</div>
            <div class="popup_weightarticle_right">
            	<a href="javascript:void(0);" onclick="closeOpenedPopup('fadefriend,datafriend,wla6')" title="Close">X</a>
            </div>
        </div>
  	<div id="content_1" class="content">	 
        <div class="popup_weightarticle_bottom">
            <div class="popup_weightarticle_main">
                <div class="popup_weightarticle_hed">How to prevent to your snack from turning into a meal</div>
                <div class="popup_weightarticle_content">
                    <img src="images/turning2.jpg" class="popup_weightarticle1" alt="turning2">
                    <p>If you ask people who are overweight what they think their extra weight is due to, many of them will tell you that snacking has had something to do with it. No surprise here.</p>
                    <p>Most people know that excessive snacking can lead to a whole lot of extra calories that our bodies don't need or want. And that the result is weight gain!</p>
                    <p>When it comes to smart snacking, there are a few things to keep in mind.</p>
                    <h1>Meals, not snacks!</h1>
                    <p>One, if you find yourself binging on snacks, then you probably have more</p>
                </div>
                <div class="popup_weightarticle_content">
                    <p> of an issue with your meals than you do with your snacks. For instance, are you going too long in between meals in which you become ravenously hungry? If so, your main obstacle here is with your meals, such as the timing and content.</p>
                    
                   	<p>If you go too long without eating, you will likely start having serious cravings for sweets. Ever been there? I have. And the next thing you know, bam, you are binging on sweets and consuming a large amount of calories in the process.</p>
                    <p>Isn't it funny that when we get that hungry because there is no food around or we don't have the time to stop and eat sensibly, that we can always find sweets to snack on? Though that 'snack' soon turns into a high calorie meal!</p>
                    <p>Not only is this bad because of the high amount of calories you just consumed, but it is detrimental because it makes eating intelligently for the rest of the day that much more difficult. And it could be the start of a bad habit as well!</p>
                    <p>Obviously, the key here is to make sure that you don't go too long without eating so that your snack doesn't turn into a high calorie meal, as well as look at what you are actually consuming at meal time.</p>
                    
                    <h2>A healthy snack</h2>
                    <p>You may ask, &quot;What constitutes a healthy snack?&quot; To start with, one that has about 150 - 200 calories. Keeping your snacks to this amount seems to be beneficial for most people.</p>
                    <p>Secondly, consuming a snack that is high in fiber or protein is a good idea as well. You don't want to eat a snack that is going to get digested too quickly because you will get hungry sooner, rather than later.</p>
                    <p>An example of a high fiber or high protein snack would be a small homemade chicken salad with calorie-free dressing. If you consumed 2&ndash;3 oz of lean skinless chicken breast, with calorie-free dressing, and some mixed greens and other vegetables, you would be below 200 kcals for this snack that should keep you full until your next meal.</p>
                    
                    <h2>Simple snack</h2>
                    <p>For a simpler snack, you could consume a piece of fruit like an apple with 1 tablespoon of peanut butter, a healthy, homemade bran muffin, or a low carb protein bar, for example.</p>
                    
                    <h2>Bottom line</h2>
                    <p>Enjoy your snack, but let the main purpose of it be to give you nutrition for energy, as well as carry you from one meal to the next without the consumption of too many calories in between!</p>
                </div>
            </div>
        </div>
        </div>

    </div>
 <?php
}?>  
<!--poppup 14 end-->





<!--poppup 15 start-->
<?php if($popupFor=='contect15'){?>
    <div class="popup_weightarticle_area">
        <div class="popup_weightarticle_top">
            <div class="popup_weightarticle_left">Weight Loss Articles</div>
            <div class="popup_weightarticle_right">
            	<a href="javascript:void(0);" onclick="closeOpenedPopup('fadefriend,datafriend,wla7')" title="Close">X</a>
            </div>
        </div>
  	<div id="content_1" class="content">	 
        <div class="popup_weightarticle_bottom">
            <div class="popup_weightarticle_main">
                <div class="popup_weightarticle_hed">3 Ways to stop gaining weight at work</div>
                <div class="popup_weightarticle_content">
                    <img src="images/gaining_weight2.jpg" class="popup_weightarticle1" alt="gaining_weight2">
                    <p>Have you ever considered that by having a job (outside your home) that it can be hazardous to your weight? This can actually be true, to an extent. But before you decide to quit your job, continue reading.</p>
                    <p>You may ask, &quot;How is this possible?&quot; Think of it this way. You start a new job and what do you know, your new colleagues have brought in some of your favorite, high calorie snacks&ndash;damn!</p>
                    <h1>Colleague's snacks</h1>
                    <p>Then you find yourself saying, &quot;Why did they have to bring that in today &ndash; I love those things!&quot; So what do you do, just resist temptation? You can try, but there is a better solution than that.</p>
                </div>
                <div class="popup_weightarticle_content">
                   	<h1>(1) Answer</h1>
                    <p>The best solution is to plan ahead and bring in your own favorite, low fat, low calorie snacks. This way, if your coworkers bring in snacks, it will be much easier to resist them knowing that you are not going to go hungry or feel deprived by avoiding them because you know you have your own delicious snacks that you would much rather have anyway.</p>
                    <p>Additionally, by the time you see the snacks that others have brought in you may have just finished your own lower calorie, tasty snacks, enjoyed them even more, and now have no desire for theirs. This can make avoiding coworker's cellulite gaining snacks that much easier!</p>
                    <h2>Fast food lunch</h2>
                    <p>Then there are the coworkers who insist that you go out for lunch. You tell them that you brought your lunch, but they moan and groan and insist, and eventually you give in and go.</p>
                    <p>Some coworkers at lunch time will want to go the cheapest route which will likely mean your typical fast food establishment which has served zillions of customers over the years. In this situation, your options are limited and you are definitely in a more difficult situation.</p>
                    <h2>(2) What you should do</h2>
                    <p>There are a couple of things you can do. Before you order anything, get your hands on their nutrition facts sheet or pamphlet.Look and see what foods are available and are lowest in calories (and grams of saturated and trans fat for heart healthy reasons).</p>
                    <p>For instance, do they have a salad with some (non&ndash;fried) chicken and some low or zero calorie dressing (versus the traditional blue cheese or ranch dressing)? Do they have a small baked potato with salsa available? You get the idea.</p>
                    <p>And for fluids, obviously going with 32 oz of soda is not going to be your friend here. How about water - tap or bottled? What else do they have on the menu &ndash; take a look!</p>
                    <p>As far as diet soda goes, many studies show that people who consume diet soda don't lose any more weight than people who consume regular soda. Try to make it a point not to consume any calories from liquids. That alone may save you from a disaster lunch.</p>
                    <p>Remember that when you go to eat at places that favor weight gain, you don't have to have as much food as you normally would. You just need to survive the experience!</p>
                    
                    <h2>(3) Know in advance</h2>
                    <p>Even better than going in and trying to figure out what options you have available to you, know ahead of time. For many places you can find out online what their choices are as well as what the nutrition facts are for each food.</p>
                    <p>Making a quick decision while you are standing on line and in a rush to get your food so that you can get back to work on time doesn't always lead to a good decision. So know before you get there!</p>
                    <p>Additionally, you don't have to think of this as &quot;lunch.&quot; Rather, you can think of it as a snack, and that you will have the lunch you brought in when it is time to have your afternoon snack.</p>
                    <p>Granted, this may not go over too well with your coworkers at the lunch table, but you need to stay committed to your goals. And from a general perspective, you certainly want to stay away from anything deep fried, such as french fries.</p>
                    <p>Also, your burgers here are loaded with grams of fat which means lots of calories. And even if you order a salad and use their typical dressings, like ranch or blue cheese, you are in for plenty of calories also (especially if you drench your salad as many people do)!</p>
                    
                    <h2>Bottom line </h2>
                    <p>Bringing your own healthy, delicious snacks with you to work will deter you from consuming your coworker's high calorie, fatty foods. For fast food meals, like lunch, determine what they have that is healthy and low calorie and stick with that, even if it means eating less. Eating out for lunch at less than desirable fast food places doesn't have to lead to weight gain city!</p>
                </div>
            </div>
        </div>
        </div>

    </div>
 <?php
}?>  
<!--poppup 15 end-->




<!--poppup 16 start-->
<?php if($popupFor=='contect16'){?>
    <div class="popup_weightarticle_area">
        <div class="popup_weightarticle_top">
            <div class="popup_weightarticle_left">Weight Loss Articles</div>
            <div class="popup_weightarticle_right">
            	<a href="javascript:void(0);" onclick="closeOpenedPopup('fadefriend,datafriend,wla8')" title="Close">X</a>
            </div>
        </div>
  	<div id="content_1" class="content">	 
        <div class="popup_weightarticle_bottom">
            <div class="popup_weightarticle_main">
                <div class="popup_weightarticle_hed">5 Steps to overcoming an obstacle</div>
                <div class="popup_weightarticle_content">
                    <img src="images/overcoming2.png" class="popup_weightarticle1" alt="overcoming2">
                    <h1>Step 1: Get Motivated to overcome it!</h1>
                    <p>If you are going to overcome an obstacle you'll need to look at the obstacle as a challenge and get motivated to overcome it. Consider what you will gain if you are successful with overcoming your obstacle as well as consider what you will lose out on if you are not successful.</p>
                    <h1>Step 2: Determine why the obstacle is there!</h1>
                    <p>Now that you know what your obstacle is and you are motivated to accomplish it, you need to ask yourself why it is there. Determining why the obstacle is there will give you tremendous insight as to how you are going to overcome it.</p>
                    
                </div>
                <div class="popup_weightarticle_content">
                    
                    <p>You need to spend some time on this. Why you think the obstacle is there may not be the real reason why it actually is there. Take your time and consider all possibilities.</p>
                   	<h2>Step 3: Repeat step 2!</h2>
                    <p>Oddly enough, once you determine why your obstacle exists, then ask yourself why that reason that you just came up with exists. For instance, one of my former patients consistently overate at dinner time, which was his number one obstacle.</p>
                    <p>He did this because he wasn't enjoying the rest of his day and looked to dinner for his day's pleasure. From there we had to determine why that reason existed, specifically, why he wasn't getting much pleasure from the rest of his day. If we hadn't looked more deeply at his issue, we wouldn't have determined what he really needed to do to be successful!</p>
                    
                    <h2>Step 4: Ask Questions to Create a Recipe!</h2>
                    <p>Subsequently, with this client the focus then became creating a recipe for success for him. What kind of a plan did we need to create in order for him to be successful? To determine this we started asking some questions which would help us decide how to go about it.</p>
                    <p>For example:</p>
                    <p>&quot;What's the first thing that needs to be done, what do we need to do this, and how will we do it?&quot;</p>
                    <p>&quot;How have you overcome a similar obstacle in the past?&quot;</p>
                    <p>&quot;What are all of the resources at your disposal?&quot;</p>
                    <p>&quot;How would someone else that you know attack the same problem?&quot;</p>
                    
                    <h2>Step 5: Time&ndash;Line &amp; Accountability!</h2>
                    <p>Now that you have a plan for overcoming your obstacle, you need to develop a time&ndash;line for when you are going to accomplish the different aspects within it. Set a deadline for when items in your plan need to be accomplished by.</p>
                    <p>And finally, have someone hold you accountable with the mini&ndash;goals that you have created in order to overcome your obstacles and accomplish your main goal.  Accountability can be your best friend when it comes to staying on track and accomplishing everything that you need to!</p>
                    
                </div>
            </div>
        </div>
        </div>

    </div>
 <?php
}?>  
<!--poppup 16 end-->





<!--poppup 17 start-->
<?php if($popupFor=='contect17'){?>
    <div class="popup_weightarticle_area">
        <div class="popup_weightarticle_top">
            <div class="popup_weightarticle_left">Weight Loss Articles</div>
            <div class="popup_weightarticle_right">
            	<a href="javascript:void(0);" onclick="closeOpenedPopup('fadefriend,datafriend,wla9')" title="Close">X</a>
            </div>
        </div>
  	<div id="content_1" class="content">	 
        <div class="popup_weightarticle_bottom">
            <div class="popup_weightarticle_main">
                <div class="popup_weightarticle_hed">Motivation: 5 keys to setting "smart" goals!</div>
                <div class="popup_weightarticle_content">
                    <img src="images/motivation2.png" class="popup_weightarticle1" alt="motivation2">
                    <p>It's extremely important to set goals &ndash; goals are what's at the heart of motivation. When we stop aiming for a goal, we forget why we are making such an effort every day.</p>
                    <p>Consequently, we stop trying so hard. When setting goals it is very important to set goals that are &quot;SMART,&quot; which includes the following:</p>
                    <h1>(1) Specific</h1>
                    <p>Make sure your goals are specific. For instance, if you want to lose weight, you need to state how much weight you want to lose (though you can always change it as you go along).</p>
                    <p>But you need to have a specific goal in mind that you are aiming for right from the beginning!</p>
                    <h1>(2) Measurable</h1>
                </div>
                <div class="popup_weightarticle_content">
                    
                    
                   	
                    <p>Your goals must be measurable. If your goals are measurable, you can then tell if you are making progress with your goals as well as if you have reached them.</p>
                    <p>For instance, if your goal is to lose 10 pounds in 10 weeks, you can measure whether or not you are achieving that goal as you work towards it each week. And at the end of the 10 weeks you can tell if you have reached your goal!</p>
                    <h2>(3) Adjustable</h2>
                    <p>It's important to be flexible with your goals. For instance, if you see that you need more (or less) time to achieve a goal, be willing to adjust your time line or even the goal itself.</p>
                    <p>Ultimately, you want to be successful with your goals and being successful often times includes being flexible.</p>
                    <h2>(4) Realistic</h2>
                    <p>Your goals should be realistic. If your goals are not realistic, you may soon lose your motivation.</p>
                    <p>It's great to expect the best from yourself and set challenging goals, but being realistic at the same time will facilitate you in accomplishing them!</p>
                    
                    <h2>(5) Timely</h2>
                    <p>Your goals should have a time line. If your goal is to lose 10 pounds, you should specify when you want to lose that weight by, such as a certain number of weeks or a specific date.</p>
                    <p>Having a timely deadline will help keep you motivated because you know you do not have an endless amount of time to accomplish your goal.the clock is ticking!</p>
                    
                    <h2>Bottom line</h2>
                    <p>Goals motivate! It's important to use good strategy when setting goals. Above are 5 key principles to include in your goal&ndash;setting plan.</p>
                    <p>And make sure to write your goals down and keep them somewhere where you'll see them everyday, as well as have someone hold you accountable with your actions. Knowing someone is going to be checking with you to make sure you are doing what you are suppose to be doing can be a much needed additional motivator as well!</p>
                </div>
            </div>
        </div>
        </div>
   
    </div>
 <?php
}?>  
<!--poppup 17 end-->





<!--poppup 18 start-->
<?php if($popupFor=='contect18'){?>
    <div class="popup_weightarticle_area">
        <div class="popup_weightarticle_top">
            <div class="popup_weightarticle_left">Weight Loss Articles</div>
            <div class="popup_weightarticle_right">
            	<a href="javascript:void(0);" onclick="closeOpenedPopup('fadefriend,datafriend,wla10')" title="Close">X</a>
            </div>
        </div>
  	<div id="content_1" class="content">	 
        <div class="popup_weightarticle_bottom">
            <div class="popup_weightarticle_main">
                <div class="popup_weightarticle_hed">Increase your awareness &amp; lose weight fast!</div>
                <div class="popup_weightarticle_content">
                    <img src="images/Increase2.png" class="popup_weightarticle1" alt="Increase2">
                    <p>In sport psychology we like to say, &quot;The first key to gaining control over any situation is awareness.&quot; In order to tackle an obstacle that is plaguing your weight loss efforts, you first have to be aware of what that obstacle is.</p>
                     <h1>Keep a food journal</h1>
                     <p>One of the most important tools used in nutrition therapy is the 'food journal.' The food journal can bring about a tremendous amount of enlightenment for us in regards to our eating habits.</p>
                    <p>First, it allows us to become aware of what we are actually eating.</p>
                </div>
                <div class="popup_weightarticle_content">
                   	<p> Because so many people 'pick' throughout the day we really aren't aware of all of the different foods we consume.</p>
                    <p>When I have looked over a client's food journal and asked them about a specific food item they consumed, often times they will look at me quite puzzled, and say, &quot;Did I really eat that?&quot;</p>
                    
                    <h2>How much did I really eat?</h2>
                    <p>And of course there is the issue of how much you have consumed. By keeping track of what food items you have consumed and how much of them, you can now see where and why you are consuming excess calories due to the sheer volume of what you have chosen to eat.</p>
                    <p>Even more puzzling to clients than seeing what items they have consumed is seeing how much of each item they have consumed.</p>
                   	
                    <h2>Don't do this</h2>
                    <p>A good example of why you should keep a food journal is eating chips right out of the bag. When we do this we aren't aware of how much we are consuming while we are eating them. And then we walk away after we're done not aware of how many calories all those chips just added up to.</p>
                    <p>If we were keeping a food journal we would have written down how much we ate and thus become aware of the amount we had consumed. Additionally, we could figure out how many calories we just consumed as well.</p>
                    
                    <h2>Why Bother</h2>
                    <p>What would be the point of journaling our chips? First it makes us aware that it is easy to consume a larger volume of food, and consequently more calories, when we aren't being mindful of how much we are consuming.</p>
                    <p>Secondly, in the future it would motivate us to pay more attention to how much we are actually consuming because we know that if we don't make the conscious effort to be aware of how much we are consuming, we'll consume more than we think and the calories will really add up!</p>
                    <p>The biggest benefit might be that it motivates us to portion out an amount that fits with our caloric needs for the day, such as an amount of chips that adds up to no more than 150 calories.</p>
                    
                    <h2>Summary</h2>
                    <p>Simply, keeping a food journal greatly facilitates us in becoming aware of what foods and how much of them we are consuming, and how many total calories we are taking in for the entire day. Because of this we tend to consume less food and calories which often times leads to losing weight fast.</p>
                    <p>From here we have a great starting point from which to work with in which we can now start to generate a meal plan that will facilitate us in reaching our weight loss goals!</p>
                </div>
            </div>
        </div>
        </div>

    </div>
 <?php
}?>
<!--poppup 18 end-->  




<!--poppup 19 start-->
<?php if($popupFor=='contect19'){?>
	
    <div class="popup_weightarticle_area">
        <div class="popup_weightarticle_top">
            <div class="popup_weightarticle_left">Weight Loss Articles</div>
            <div class="popup_weightarticle_right">
            	<a href="javascript:void(0);" onclick="closeOpenedPopup('fadefriend,datafriend,wla4')" title="Close">X</a>
            </div>
        </div>
    	<div id="content_1" class="content">	 
        <div class="popup_weightarticle_bottom">
            <div class="popup_weightarticle_main">
                <div class="popup_weightarticle_hed">GETTING STARTED WITH TRAINING</div>
                <div class="popup_weightarticle_content">
                    <img src="images/older_man_abs.jpg" class="popup_weightarticle1" alt="prevent_overeating2">
                    <p>Many people who would like to better manage their weight would like to start working out, but they have 'approach-avoidance' issues. Simply, they may start to take the steps that will lead them to working out each week (approach), but then there is something that holds them back and they never get started, or, start to only stop almost immediately and not get started again (avoidance). 
</p>
<h1>FEAR</h1>
					<p>One main reason people have approach-avoidance towards working out, simply, is fear. Most of us have been in some type of gym setting before. But for many of us it was a long time ago! And we want to get back into working out, but avoid it because of fear. For starters, one thing they fear is that they will get hurt while working out because they know that they really don't know how to do the exercises or use the machines properly. So they avoid it altogether.
</p>
					<h1>NAGGING INJURIES</h1>
                    <p>Interestingly enough, these individuals have good reason to believe they will get hurt. In addition to lacking enough knowledge about the equipment and exercises, another reason they might get hurt is that they have some areas of their body which are problematic, what you might call nagging injuries. Not knowing how to compensate for these old injuries can lead them to get hurt quite quickly and then decide that they are never coming back to the gym! Or if they do keep working out, they may totally avoid working out any body parts that involve these muscles, which can also be a very big mistake sometimes. 
</p>
<h1>TARGET LIMITATIONS</h1>
					<p>One of the jobs of a good personal trainer is to first identify which areas of a client's body are troublesome or have the potential to be. Then the client and trainer put together a plan that works out the entire body, but avoids placing this body part in harms way.  And additionally, learning how to stretch and strengthen this area needs to be addressed and become a priority.  
</p><p>
And lastly, many people fear that while trying to figure out how to use the equipment that they may look really, really dumb :) in the gym and they know they don't want to look or feel dumb! So they avoid the gym altogether for this reason as well. 
</p>        
<h1>UTILIZE AVAILABLE RESOURCES</h1>
<p>Simply, don't let fear (as rational as it might or might not be) get in your way of creating a better, healthier body. Utilize the help of a qualified personal trainer, as well as a physical therapist, to reach your goals. Getting started with an exercise program can be intimidating for many reasons, but you can utilize the help of others to get you started down the path to a healthier you. You have the power to get started, and if you do, you will likely be very glad that you did!
</p>     
                </div>
                
            
            </div>
        </div>
        </div>

    </div>
 <?php
}?>
<!--poppup 19 end-->  




<!--poppup 20 start-->
<?php if($popupFor=='contect20'){?>
	
    <div class="popup_weightarticle_area">
        <div class="popup_weightarticle_top">
            <div class="popup_weightarticle_left">Weight Loss Articles</div>
            <div class="popup_weightarticle_right">
            	<a href="javascript:void(0);" onclick="closeOpenedPopup('fadefriend,datafriend,wla4')" title="Close">X</a>
            </div>
        </div>
    	<div id="content_1" class="content">	 
        <div class="popup_weightarticle_bottom">
            <div class="popup_weightarticle_main">
                <div class="popup_weightarticle_hed">WORKING OUT AT HOME – GETTING STARTED</div>
                <div class="popup_weightarticle_content">
                    <img src="images/2_ladies_on_mat_abs.jpg" class="popup_weightarticle1" alt="prevent_overeating2">
                    <p>Are you one of the many people who do not enjoy working out in a gym setting? Would you prefer to work out at home? Many people would and should consider this option. But before you get started working out at home or starting an exercise program, get medical clearance from your physician first!
					</p>
					<h1>BE IN THE KNOW!</h1>
                    <p>So let's say you have been given medical clearance, in order to burn calories and create a better body, you don't have to huff and puff in a gym setting with lots of strangers. You can get a great workout at home! However, you should know what to do and how to do it to maximize effectiveness and minimize risk of injury. 
</p>					
<h1>USE PROPER FORM</h1>
                    <p>For instance, if you want to lift dumbbells at home you might think 'lifting dumbbells is a no-brainer.' Well your right in that it is not quantum physics, but like most everything else, there is a right and a wrong way to do things. For instance, when lifting dumbbells, how is your form? For a lot of beginners, their form when it comes to this 'simple' task, is atrocious! 
 </p> <p>
For instance, whenever I walk past a fitness center that has large windows where you can easily look in and see lots of people lifting weights, I am almost always amazed as to the horrible form that people use. Literally, it looks like they are working out a different body part than the body part that is intended to be worked by that exercise, truly. 
 </p> <p>
For instance, when doing standing dumbbell curls, their form is so bad that they seem to be working their shoulders and back more than their biceps. This sounds ridiculous because it is ridiculous!! So if you want to work out at home, make sure you know what proper form really looks like and use that form. 
</p>    
<h1>PHYSICAL LIMITATIONS</h1>	
<p>Keep in mind that proper form for you may be somewhat different than what it is for someone else because of physical limitations that you may have. And if your physical limitations lead you to think you need to use bad form, then either find out how to do that exercise properly from a qualified professional, or pick a different exercise. Don't use physical limitations as an excuse to workout improperly. 
</p>
<h1>LIMITED RESULTS</h1>
<p>Secondly, you need to know numerous exercises for each body part. You need to know this because if you only do the same exercise for a certain body part every time you workout that body part, your body will get used to that exercise quickly and you will stop seeing much, if any improvement. So you need to know multiple exercises for each body part and how to do them correctly.
</p>
<h1>CORE</h1>
<p>
One of the most important things that should be addressed when starting (or re-starting) an exercise program is your core. Core includes, but is not limited to your abdominals, glutes, torso and lower back. In order to progress with exercises that use weights for any exercise, you will need to have strong core muscles for numerous reasons.
 </p> <p>
First, you don't want to pull any of your core muscles when working out because that will limit your choice of exercises after that since every exercise incorporates at least some of your core muscles. Plus, of course, nobody wants to pull or strain a muscle anywhere! All strength starts and emanates from the core so it is extremely important to get it and keep it strong. 
 </p> <p>
Also, as you start to move up in weight with your exercises, you will notice a much stronger need to have strong core muscles. Literally, if your core is weak, you will find it difficult to utilize proper form for weight lifting exercises as the weight becomes heavier as you get stronger. So even if you don't pull a muscle with a weak core, it can negatively impact your workouts in other ways!
</p>   <h1>TAKE-HOME MESSAGE</h1>
<p>The take-home message here is if working out at home works for you, consider doing it! But first find out what to do and how to do it correctly to maximize calorie burning and decrease risk of injuty!
Good luck!</p>             
                </div>
                
               
            </div>
        </div>
        </div>

    </div>
 <?php
}?>
<!--poppup 20 end-->  

 <!-------------------------Weight Loss Articles  page html start----------------------------------------->
 

 
<script>
$(document).ready(function (){
	setpopup();
	});
//setTimeout('setpopup()', 500);
function setpopup(){
	
	if($("#content_1").length>0){
	//$('#content_1').height(500);	
		$("#content_1").mCustomScrollbar({
			scrollButtons:{
				enable:true
			}
		});
	}
}
</script>

