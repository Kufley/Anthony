<?php if (file_exists($_SERVER['DOCUMENT_ROOT'].'/zblock/zbblock.php')) require($_SERVER['DOCUMENT_ROOT'].'/zblock/zbblock.php'); ?><?php
require_once('include/mainConnect.php');
require_once($config['absolute_path'].'classes/main.php');	
include('includes/header.php') ;?> 
 
    

   <!--CONTENT AREA START-->
        <div class="content_area">
            <div class="med_area">
            	<div class="med_arealeft">
                	<div class="meetanthony_area">
                    	<div class="registered_area">
                            <div class="inner_hed">
                                Weight Loss Articles
                            </div>
            			</div>
                        <div class="left_panel">
                          	<div class="articles_text">
                            	<p>Anthony Wilson is a Registered Dietitian (RD), Certified Personal Trainer, and Behavior Therapist. Over the past 15 years Anthony has successfully facilitated many diabetic &amp; non-diabetic individuals with overcoming their obstacles and attaining their desired body weight.</p>
                         
                     <p style="margin-top:10px;">These articles will help you gain expert nutrition advice and valuable insights into how behavioral principles and techniques help achieve desired body weight and better health.</p>
                          	</div>
                            <div class="weight_articles_area">
                            	<div class="weight_articles_main">
                                	<div class="permanent_weight_main">
                                    	<div class="permanent_weight_top">
 											<a href="#" name="wla1" onClick="openPopup('fadefriend',1,'fade_popup','datafriend',2,'data_on_fade','contect9');">               
                                            <img src="images/permanent_weight_loss.png" alt="permanent_weight_loss" /></a>
                                        </div>
                                        <div class="permanent_weight_bottom">
                                        	<a href="#" onClick="openPopup('fadefriend',1,'fade_popup','datafriend',2,'data_on_fade','contect9');">
                                            4 Steps to<br />
                                            permanent<br />
                                            weight loss</a>
                                        </div>
                                   	</div>
                                    
                                    <div class="permanent_weight_main">
                                    	<div class="permanent_weight_top">
                                        	<a href="#" name="wla2" onClick="openPopup('fadefriend',1,'fade_popup','datafriend',2,'data_on_fade','contect10');">
                                            <img src="images/fat_grams.png" alt="fat_grams" /></a>
                                        </div>
                                        <div class="permanent_weight_bottom">
                                        	<a href="#" onClick="openPopup('fadefriend',1,'fade_popup','datafriend',2,'data_on_fade','contect10');">
                                            Fat grams<br />
                                            vs. Calories:<br />
                                            who wins?</a>
                                        </div>
                                   	</div>
                                    
                                    <div class="permanent_weight_main">
                                    	<div class="permanent_weight_top">
                                        	<a href="#" name="wla3" onClick="openPopup('fadefriend',1,'fade_popup','datafriend',2,'data_on_fade','contect11');">
                                            <img src="images/practices.jpg" alt="practices" /></a>
                                        </div>
                                        <div class="permanent_weight_bottom">
                                        	<a href="#" onClick="openPopup('fadefriend',1,'fade_popup','datafriend',2,'data_on_fade','contect11');">
                                            3 Practices to<br />
                                           drastically reduce<br />
                                            your calories</a>
                                        </div>
                                   	</div>
                                    
                                    <div class="permanent_weight_main2">
                                    	<div class="permanent_weight_top">
                                        	<a href="#" name="wla4" onClick="openPopup('fadefriend',1,'fade_popup','datafriend',2,'data_on_fade','contect12');">
                                            <img src="images/prevent_overeating.png" alt="prevent_overeating" /></a>
                                        </div>
                                        <div class="permanent_weight_bottom">
                                        	<a href="#" onClick="openPopup('fadefriend',1,'fade_popup','datafriend',2,'data_on_fade','contect12');">
                                            3 Keys to prevent <br />
                                            overeating</a>
                                        </div>
                                   	</div>
                                </div>
                                
                                
                                <div class="weight_articles_main">
                                	<div class="permanent_weight_main">
                                    	<div class="permanent_weight_top">
                                        	<a href="#" name="wla5" onClick="openPopup('fadefriend',1,'fade_popup','datafriend',2,'data_on_fade','contect13');">
                                            <img src="images/avoid.jpg" alt="avoid" /></a>
                                        </div>
                                        <div class="permanent_weight_bottom">
                                        	<a href="#" onClick="openPopup('fadefriend',1,'fade_popup','datafriend',2,'data_on_fade','contect13');">
                                            How to avoid <br />
                                            binging after work</a>
                                        </div>
                                   	</div>
                                    
                                    <div class="permanent_weight_main">
                                    	<div class="permanent_weight_top">
                                        	<a href="#" name="wla6" onClick="openPopup('fadefriend',1,'fade_popup','datafriend',2,'data_on_fade','contect14');">
                                            <img src="images/turning.jpg" alt="turning" /></a>
                                        </div>
                                        <div class="permanent_weight_bottom">
                                        	<a href="#" onClick="openPopup('fadefriend',1,'fade_popup','datafriend',2,'data_on_fade','contect14');">
                                            How to prevent your<br />
                                            snack from turning<br />
                                            into a meal</a>
                                        </div>
                                   	</div>
                                    
                                    <div class="permanent_weight_main">
                                    	<div class="permanent_weight_top">
                                        	<a href="#" name="wla7" onClick="openPopup('fadefriend',1,'fade_popup','datafriend',2,'data_on_fade','contect15');">
                                            <img src="images/gaining_weight.jpg" alt="gaining_weight" /></a>
                                        </div>
                                        <div class="permanent_weight_bottom">
                                        	<a href="#" onClick="openPopup('fadefriend',1,'fade_popup','datafriend',2,'data_on_fade','contect15');">
                                            3 Ways to stop <br />
                                            gaining weight<br />
                                            at work</a>
                                        </div>
                                   	</div>
                                    
                                    <div class="permanent_weight_main2">
                                    	<div class="permanent_weight_top">
                                        	<a href="#" name="wla8" onClick="openPopup('fadefriend',1,'fade_popup','datafriend',2,'data_on_fade','contect16');">
                                            <img src="images/overcoming.png" alt="overcoming" /></a>
                                        </div>
                                        <div class="permanent_weight_bottom">
                                        	<a href="#" onClick="openPopup('fadefriend',1,'fade_popup','datafriend',2,'data_on_fade','contect16');">
                                            5 Steps to <br />
                                            overcoming an<br />
                                            obstacle</a>
                                        </div>
                                   	</div>
                                </div>
                                
                                
                                <div class="weight_articles_main">
                                	<div class="permanent_weight_main">
                                    	<div class="permanent_weight_top">
                                        	<a href="#" name="wla9" onClick="openPopup('fadefriend',1,'fade_popup','datafriend',2,'data_on_fade','contect17');">
                                            <img src="images/motivation1.png" alt="motivation1" /></a>
                                        </div>
                                        <div class="permanent_weight_bottom">
                                        	<a href="#" onClick="openPopup('fadefriend',1,'fade_popup','datafriend',2,'data_on_fade','contect17');">
                                            Motivation:<br />
                                            5 keys to setting <br />
                                            “smart” goals!</a>
                                        </div>
                                   	</div>
                                    
                                    <div class="permanent_weight_main">
                                    	<div class="permanent_weight_top">
                                        	<a href="#" name="wla10" onClick="openPopup('fadefriend',1,'fade_popup','datafriend',2,'data_on_fade','contect18');">
                                            <img src="images/Increase.png" alt="Increase" /></a>
                                        </div>
                                        <div class="permanent_weight_bottom">
                                        	<a href="#" onClick="openPopup('fadefriend',1,'fade_popup','datafriend',2,'data_on_fade','contect18');">
                                            Increase your <br />
                                            awareness &amp; lose<br />
                                            weight fast!</a>
                                        </div>
                                   	</div>
                                    
									     <div class="permanent_weight_main">
                                    	<div class="permanent_weight_top">
                                        	<a href="#" name="wla3" onClick="openPopup('fadefriend',1,'fade_popup','datafriend',2,'data_on_fade','contect19');">
                                            <img src="images/olderman.jpg" alt="practices" /></a>
                                        </div>
                                        <div class="permanent_weight_bottom">
                                        	<a href="#" onClick="openPopup('fadefriend',1,'fade_popup','datafriend',2,'data_on_fade','contect19');">
                                            Getting  <br />
                                        started  <br />
                                           with training</a>
                                        </div>
                                   	</div>
                                    
                                    <div class="permanent_weight_main2">
                                    	<div class="permanent_weight_top">
                                        	<a href="#" name="wla4" onClick="openPopup('fadefriend',1,'fade_popup','datafriend',2,'data_on_fade','contect20');">
                                            <img src="images/2ladies.jpg" alt="prevent_overeating" /></a>
                                        </div>
                                        <div class="permanent_weight_bottom">
                                        	<a href="#" onClick="openPopup('fadefriend',1,'fade_popup','datafriend',2,'data_on_fade','contect20');">
                                            Working out  <br />
                                            at home</a>
                                        </div>
                                   	</div>
									
									
									
                                </div>
                            </div>
                            
                        </div>
                    </div>
                    
                </div>
                <div class="rightpanelarea"></div>
                <?php include('includes/rightpanel.php') ;?>
                <div class="question">
                	Questions? <span><a href="contactus.php">Contact Anthony</a></span> or email 
                    <span><a href="mailto:Anthony@WeightLossHappens.com">Anthony@WeightLossHappens.com</a></span>
                </div>
            </div>
        </div>
        <!--CONTENT AREA END--><script type="text/javascript">
//alert('hi'); 
$('#weight_loss_articles').addClass("current");

</script> 
      <?php include('includes/footer.php') ;?>  
      
      
      
                